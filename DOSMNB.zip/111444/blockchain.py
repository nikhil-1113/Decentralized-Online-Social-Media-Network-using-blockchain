import time
import json
import hashlib
import uuid


def compute_hash(data: str):
    return hashlib.sha256(data.encode()).hexdigest()


class Block:
    def __init__(self, index, transactions, previous_hash, timestamp=None, nonce=0):
        self.index = index
        self.transactions = transactions  # list of transactions (dicts)
        self.previous_hash = previous_hash
        self.timestamp = timestamp or time.time()
        self.nonce = nonce
        self.hash = self.compute_hash()

    def compute_hash(self):
        block_string = json.dumps(
            {
                "index": self.index,
                "transactions": self.transactions,
                "previous_hash": self.previous_hash,
                "timestamp": self.timestamp,
                "nonce": self.nonce,
            },
            sort_keys=True,
        )
        return compute_hash(block_string)

    def to_dict(self):
        return {
            "index": self.index,
            "transactions": self.transactions,
            "previous_hash": self.previous_hash,
            "timestamp": self.timestamp,
            "nonce": self.nonce,
            "hash": self.hash,
        }


class Blockchain:
    def __init__(self, difficulty=3):
        self.unconfirmed_transactions = []  # pending transactions
        self.chain = []
        self.difficulty = difficulty
        self.create_genesis_block()

    def create_genesis_block(self):
        genesis_block = Block(0, [], "0", time.time(), 0)
        genesis_block.hash = genesis_block.compute_hash()
        self.chain.append(genesis_block)

    @property
    def last_block(self):
        return self.chain[-1]

    def add_new_transaction(self, transaction: dict):
        # transaction should be a dict with required fields
        transaction.setdefault("id", str(uuid.uuid4()))
        transaction.setdefault("timestamp", time.time())
        self.unconfirmed_transactions.append(transaction)

    def proof_of_work(self, block: Block):
        block.nonce = 0
        computed_hash = block.compute_hash()
        target = "0" * self.difficulty
        while not computed_hash.startswith(target):
            block.nonce += 1
            computed_hash = block.compute_hash()
        return computed_hash

    def mine(self, miner_address=None):
        if not self.unconfirmed_transactions:
            return None

        new_block = Block(
            index=self.last_block.index + 1,
            transactions=self.unconfirmed_transactions,
            previous_hash=self.last_block.hash,
        )
        proof = self.proof_of_work(new_block)
        new_block.hash = proof
        self.chain.append(new_block)

        # reward transaction for miner (optional)
        if miner_address:
            reward_tx = {"type": "reward", "recipient": miner_address, "amount": 1, "timestamp": time.time()}
            self.unconfirmed_transactions = [reward_tx]
        else:
            self.unconfirmed_transactions = []

        return new_block.to_dict()

    def to_dict(self):
        return {"chain": [b.to_dict() for b in self.chain], "difficulty": self.difficulty}

    def find_transactions_for_recipient(self, recipient_username):
        txs = []
        for block in self.chain:
            for tx in block.transactions:
                if tx.get("recipient") == recipient_username:
                    txs.append({"block_index": block.index, "tx": tx})
        # also include pending transactions
        for tx in self.unconfirmed_transactions:
            if tx.get("recipient") == recipient_username:
                txs.append({"block_index": None, "tx": tx})
        return txs
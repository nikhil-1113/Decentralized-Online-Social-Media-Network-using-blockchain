import base64
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.fernet import Fernet


def generate_rsa_keys(key_size: int = 2048):
    """
    Generate an RSA key pair and return (private_pem, public_pem) as bytes.
    """
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=key_size)
    private_pem = private_key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    public_pem = private_key.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return private_pem, public_pem


def encrypt_for_recipient(plaintext: str, recipient_public_pem: bytes):
    """
    End-to-end style encryption: generate a random Fernet key, encrypt plaintext with Fernet,
    then encrypt the Fernet key with recipient's RSA public key (OAEP).
    Returns (ciphertext_token_str, encrypted_sym_key_b64).
    """
    # generate Fernet key for symmetric encryption
    fernet_key = Fernet.generate_key()
    f = Fernet(fernet_key)
    token = f.encrypt(plaintext.encode())  # bytes

    # load recipient public key
    public_key = serialization.load_pem_public_key(recipient_public_pem)

    # encrypt Fernet key using recipient's public key
    enc_sym = public_key.encrypt(
        fernet_key,
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
    )
    enc_sym_b64 = base64.b64encode(enc_sym).decode()

    return token.decode(), enc_sym_b64


def decrypt_message(ciphertext_token_str: str, enc_sym_b64: str, recipient_private_pem: bytes):
    """
    Decrypts the encrypted symmetric key with recipient private key, then decrypts the token.
    Returns plaintext string.
    """
    token = ciphertext_token_str.encode()
    enc_sym = base64.b64decode(enc_sym_b64.encode())

    private_key = serialization.load_pem_private_key(recipient_private_pem, password=None)

    fernet_key = private_key.decrypt(
        enc_sym,
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
    )
    f = Fernet(fernet_key)
    plaintext = f.decrypt(token).decode()
    return plaintext


def serialize_private_key_to_file(private_pem: bytes, path: str):
    with open(path, "wb") as f:
        f.write(private_pem)


def serialize_public_key_to_bytes(public_pem: bytes):
    return public_pem
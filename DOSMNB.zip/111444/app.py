import os
import json
import io
from flask import Flask, render_template, request, redirect, url_for, session, send_file, flash
from blockchain import Blockchain
from crypto_utils import generate_rsa_keys, serialize_private_key_to_file, serialize_public_key_to_bytes, encrypt_for_recipient, decrypt_message

app = Flask(__name__)
app.secret_key = "dev-secret-key"  # for demo only

DATA_DIR = "data"
USERS_FILE = os.path.join(DATA_DIR, "users.json")
PRIVATE_KEYS_DIR = os.path.join(DATA_DIR, "private_keys")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PRIVATE_KEYS_DIR, exist_ok=True)

# load or init users
if os.path.exists(USERS_FILE):
    with open(USERS_FILE, "r") as f:
        users = json.load(f)
else:
    users = {}  # username -> {"public_key": PEM string, "registered_at": timestamp}
    with open(USERS_FILE, "w") as f:
        json.dump(users, f)

# Create blockchain instance (in-memory)
blockchain = Blockchain(difficulty=3)


def save_users():
    with open(USERS_FILE, "w") as f:
        json.dump(users, f)


@app.route("/")
def index():
    return render_template("index.html", logged_in=("username" in session), username=session.get("username"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        if not username:
            flash("Username required", "error")
            return redirect(url_for("register"))
        if username in users:
            flash("Username already exists", "error")
            return redirect(url_for("register"))

        private_pem, public_pem = generate_rsa_keys()
        users[username] = {"public_key": public_pem.decode(), "registered_at": None}
        save_users()

        # Save private key to file for user to download
        priv_path = os.path.join(PRIVATE_KEYS_DIR, f"{username}_private.pem")
        serialize_private_key_to_file(private_pem, priv_path)

        flash(f"Registered {username}. Download your private key and keep it safe!", "success")
        return render_template("register.html", private_key_path=priv_path, username=username)

    return render_template("register.html", private_key_path=None, username=None)


@app.route("/download_private/<username>")
def download_private(username):
    path = os.path.join(PRIVATE_KEYS_DIR, f"{username}_private.pem")
    if not os.path.exists(path):
        flash("Private key not found.", "error")
        return redirect(url_for("register"))
    return send_file(path, as_attachment=True, download_name=f"{username}_private.pem")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        uploaded_key = request.files.get("private_key_file")
        pasted_key = request.form.get("private_key_pasted", "").strip()
        if username not in users:
            flash("Unknown user", "error")
            return redirect(url_for("login"))
        private_pem = None
        if uploaded_key and uploaded_key.filename:
            private_pem = uploaded_key.read()
        elif pasted_key:
            private_pem = pasted_key.encode()
        else:
            flash("Provide private key file or paste private key content to decrypt messages.", "error")
            return redirect(url_for("login"))

        # store username and private key in session (for demo only)
        session["username"] = username
        session["private_key"] = private_pem.decode()
        flash(f"Logged in as {username}.", "success")
        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.pop("username", None)
    session.pop("private_key", None)
    flash("Logged out.", "info")
    return redirect(url_for("index"))


@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    if "username" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))
    username = session["username"]
    # get list of other users
    other_users = [u for u in users.keys() if u != username]
    # show messages for this user (on-chain & pending)
    txs = blockchain.find_transactions_for_recipient(username)
    # also include outgoing transactions created by this user (for history)
    outgoing = []
    for block in blockchain.chain:
        for tx in block.transactions:
            if tx.get("sender") == username:
                outgoing.append({"block_index": block.index, "tx": tx})
    for tx in blockchain.unconfirmed_transactions:
        if tx.get("sender") == username:
            outgoing.append({"block_index": None, "tx": tx})

    return render_template(
        "dashboard.html",
        username=username,
        users=users,
        other_users=other_users,
        incoming=txs,
        outgoing=outgoing,
    )


@app.route("/send_message", methods=["POST"])
def send_message():
    if "username" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))
    sender = session["username"]
    recipient = request.form.get("recipient")
    message = request.form.get("message", "")
    if not recipient or recipient not in users:
        flash("Recipient invalid", "error")
        return redirect(url_for("dashboard"))
    if not message:
        flash("Message empty", "error")
        return redirect(url_for("dashboard"))

    recipient_public_pem = users[recipient]["public_key"].encode()
    ciphertext_token_str, enc_sym_b64 = encrypt_for_recipient(message, recipient_public_pem)

    tx = {
        "type": "message",
        "sender": sender,
        "recipient": recipient,
        "ciphertext": ciphertext_token_str,
        "enc_sym_key": enc_sym_b64,
        "forwarded": False,
        "original_sender": sender,
    }
    blockchain.add_new_transaction(tx)
    flash("Message added to pending transactions. Click Mine to commit it to the chain.", "success")
    return redirect(url_for("dashboard"))


@app.route("/mine")
def mine():
    miner = session.get("username", "anonymous")
    block = blockchain.mine(miner_address=miner)
    if not block:
        flash("No pending transactions to mine.", "info")
    else:
        flash(f"Mined block {block['index']}.", "success")
    return redirect(url_for("dashboard"))


@app.route("/view_message/<tx_id>", methods=["GET", "POST"])
def view_message(tx_id):
    if "username" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))
    username = session["username"]
    private_key_pem = session.get("private_key")
    if not private_key_pem:
        flash("Private key not in session: upload or paste it at login to decrypt messages.", "error")
        return redirect(url_for("login"))

    # find transaction by id in chain or pending
    found = None
    for block in blockchain.chain:
        for tx in block.transactions:
            if tx.get("id") == tx_id:
                found = tx
                break
        if found:
            break
    if not found:
        for tx in blockchain.unconfirmed_transactions:
            if tx.get("id") == tx_id:
                found = tx
                break
    if not found:
        flash("Transaction not found", "error")
        return redirect(url_for("dashboard"))

    if found.get("recipient") != username:
        flash("You are not the recipient of that message or you cannot decrypt it.", "error")
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        # Decrypt using private key provided in session
        try:
            plaintext = decrypt_message(found["ciphertext"], found["enc_sym_key"], private_key_pem.encode())
        except Exception as e:
            flash(f"Decryption failed: {str(e)}", "error")
            return redirect(url_for("dashboard"))
        return render_template("view_message.html", tx=found, plaintext=plaintext)

    return render_template("view_message.html", tx=found, plaintext=None)


@app.route("/forward/<tx_id>", methods=["GET", "POST"])
def forward(tx_id):
    if "username" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))
    username = session["username"]
    private_key_pem = session.get("private_key")
    if not private_key_pem:
        flash("Private key required in session to forward (you must be able to decrypt).", "error")
        return redirect(url_for("login"))

    # find transaction
    found = None
    for block in blockchain.chain:
        for tx in block.transactions:
            if tx.get("id") == tx_id:
                found = tx
                break
        if found:
            break
    if not found:
        for tx in blockchain.unconfirmed_transactions:
            if tx.get("id") == tx_id:
                found = tx
                break
    if not found:
        flash("Transaction not found", "error")
        return redirect(url_for("dashboard"))

    # Ensure current user can decrypt (i.e., recipient)
    if found.get("recipient") != username:
        flash("You can only forward messages that were sent to you (for this demo).", "error")
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        new_recipient = request.form.get("new_recipient")
        if not new_recipient or new_recipient not in users:
            flash("Invalid new recipient", "error")
            return redirect(url_for("dashboard"))
        # decrypt original
        try:
            plaintext = decrypt_message(found["ciphertext"], found["enc_sym_key"], private_key_pem.encode())
        except Exception as e:
            flash(f"Decryption failed: {str(e)}", "error")
            return redirect(url_for("dashboard"))

        # encrypt for new recipient
        recipient_public_pem = users[new_recipient]["public_key"].encode()
        ciphertext_token_str, enc_sym_b64 = encrypt_for_recipient(plaintext, recipient_public_pem)
        tx = {
            "type": "message",
            "sender": username,
            "recipient": new_recipient,
            "ciphertext": ciphertext_token_str,
            "enc_sym_key": enc_sym_b64,
            "forwarded": True,
            "original_sender": found.get("original_sender", found.get("sender")),
        }
        blockchain.add_new_transaction(tx)
        flash("Forwarded message added to pending transactions. Mine to commit.", "success")
        return redirect(url_for("dashboard"))

    # GET: show forward form
    other_users = [u for u in users.keys() if u != username]
    return render_template("forward.html", tx=found, users=other_users)


@app.route("/chain")
def view_chain():
    chain_dict = blockchain.to_dict()
    return render_template("chain.html", chain=chain_dict)


if __name__ == "__main__":
    app.run(debug=True)
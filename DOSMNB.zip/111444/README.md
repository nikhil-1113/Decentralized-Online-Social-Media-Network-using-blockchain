# Decentralized Online Social Network (Demo)

This repository contains a simplified demo of a decentralized online social network:
- Uses a basic Proof-of-Work blockchain to store posts and encrypted messages.
- End-to-end encryption (E2E) for messages using RSA (key exchange) + Fernet (AES) symmetric encryption.
- Message forwarding (like WhatsApp): a logged-in recipient can forward decrypted messages to others (re-encrypted for new recipients) or forward as-is when allowed.
- Simple Flask web UI to interact with the system.

NOTE: This is a demo. Private keys are stored or uploaded for convenience — for real E2E systems, private keys must remain on the user device and never be uploaded to servers.

## Project structure

- app.py — Flask application (main)
- blockchain.py — Block and Blockchain classes
- crypto_utils.py — RSA/Fernet key generation, encryption, decryption helpers
- templates/ — HTML templates (Jinja2)
- static/style.css — Styling
- requirements.txt — Python dependencies
- data/ — runtime data (created on first run): users.json, private key files, optional chain persistence

## Prerequisites

- Python 3.8+
- Recommended: create and use a virtual environment

## Setup

1. Clone or copy the files into a directory.
2. Create a virtual environment (optional but recommended):
   - python3 -m venv venv
   - On Windows: venv\Scripts\activate
   - On macOS/Linux: source venv/bin/activate
3. Install dependencies:
   - pip install -r requirements.txt

## Run

1. Start the Flask app:
   - python app.py
2. Open your browser and go to:
   - http://127.0.0.1:5000

## How to use (step-by-step demo)

1. Register two users (e.g., alice and bob):
   - Go to "Register".
   - Enter a username and click "Register". A private key file download link will appear. Save that private key file securely — it's required to decrypt messages.
   - The server stores only the public key for each user.

2. Log in as Alice:
   - Go to "Login".
   - Enter username (alice) and upload the private key file you downloaded (or paste the private key content).
   - After successful login you will be on the dashboard.

3. Send a message:
   - In the dashboard "Send Message" area, choose recipient (bob), write message (e.g., "Hello Bob"), and "Send".
   - The server uses Bob's public key to encrypt a symmetric key and stores the encrypted message and encrypted symmetric key in a pending transaction.

4. Mine a block:
   - Click "Mine Pending Transactions" to include pending messages into a new block. This simulates decentralized mining.

5. Log out and log in as Bob:
   - Log out from Alice.
   - Log in as Bob by uploading Bob's private key file.
   - On Bob's dashboard, he will see the new message(s). Click "View/Decrypt" to decrypt and read them using Bob's private key stored in your session (only within the browser session).

6. Forward a message (WhatsApp-like):
   - While logged in as Bob, view a message and click "Forward". Choose a recipient (e.g., alice).
   - The message will be decrypted (only possible because Bob uploaded his private key) and re-encrypted for the chosen recipient(s). A new transaction is created with forwarded=true and original_sender preserved.
   - Mine pending transactions to commit the forwarded message to the chain. The new recipient(s) can then log in and decrypt the forwarded message with their private keys.

7. View the blockchain:
   - Click "View Full Chain" to see blocks and transactions.

## Storage & Security Notes

- For demo convenience:
  - The server stores user public keys in `data/users.json`.
  - The server writes private key PEM files under `data/private_keys/<username>_private.pem` for download at registration, but does NOT use them unless a user uploads them at login. In real systems, you would never store or upload private keys to a centralized server.
- This demo is intended to showcase the mechanics of storing encrypted messages in a blockchain and how E2E encryption and forwarding can be implemented in principle.

## Files (overview)

- app.py : Flask routes and UI handling
- blockchain.py : Block, Blockchain, transaction handling, mining
- crypto_utils.py : RSA key generation, serialization, encrypt/decrypt functions
- templates/*.html : Jinja2 templates for pages
- static/style.css : Stylesheet

## Extending / Production Considerations

- Move key generation and message encryption entirely to client-side (browser or native app) so private keys never leave user devices.
- Use secure, audited crypto libraries and follow best practices for key storage and exchange.
- Implement a real P2P network for blockchain nodes and consensus, not a single centralized miner.
- Add authentication and secure sessions (HTTPS, secure cookies).
- Input validation and rate-limiting.

---

If you want, I can:
- Convert encryption to fully client-side (browser) using WebCrypto and only store ciphertexts on the server.
- Add persistent chain storage and multiple node simulation.
- Provide Dockerfile for easy deployment.

Enjoy exploring the demo!
